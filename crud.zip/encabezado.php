<header id="encabezado" class="containerhead"> <a href="">
  <center>
	<img src="/Imagenes/logo-YC.png" width="269" height="192" alt=""/><img src="/Imagenes/libreria1.png" width="441" height="225" alt=""/>
	</center>
	<!-- The fixed navbar will overlay your other content, unless you add padding to the bottom of the <body>. Tip: By default, the navbar is 50px high.  -->
<nav class="navbar navbar-expand-lg navbar-dark bg-transparent">

   <div class="collapse navbar-collapse " id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
         <li class="nav-item active ">
            <a class="nav-link" href="/index.php">Inicio <span class="sr-only">(current)</span></a>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="/paginas/libros.php">Libros</a>
         </li>
         
         <li class="nav-item">
            <a class="nav-link" href="/paginas/autores.php">Autores</a>
         </li>
         <li class="nav-item">
            <a class="nav-link" href="#"> 

            	<span data-toggle="modal" data-target="#insertarModal">
				Contacto</a>	</span>




            
            
         </li>
         
      </ul>


      <?php  

         /*<form id = "form" action="?" method="post" class="form-inline my-2 my-lg-0">

      <div id='datos'>


         <input id ="keywords" name = "texto" class="form-control mr-sm-2" type="text" placeholder="Ingresar palabra clave" aria-label="Ingresar palabra clave" value ="<?php if (isset($texto))echo $texto ?>">
         <button id ="search" class="btn btn-outline-success my-2 my-sm-0" type="submit">Buscar</button>
      </form>

      */


      ?>
      



         </div>


   </div>
</nav>

  </header>






	